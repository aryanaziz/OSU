README:

To run on Flip, compile: "g++ CtoZ.cpp"

There is a constant in the code titled: arraySize
Change this value if you're passing in a starting array different than 100. This changes how algorithm 4 will react. 

Lines 296/297 define which algorithm will run. Simply uncomment one of them and comment the other to change which one is running. 

Both algorithms will output to: output.txt



When finally running, include the input file txt in the command line: "./outputFile textFile.txt"