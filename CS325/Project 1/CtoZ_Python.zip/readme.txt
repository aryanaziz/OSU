To run with an input file of numerical arrays formatted like CtZ_Problems.txt:

	python subarray.py input-file.txt


Output is to stdout, redirect to file if desired:

	python subarray.py input-file.txt > output-file.txt
