#!/usr/bin/env python

# Project 1, Team Python

# Aziz Aryan & Bryon Burleigh


import fileinput
import random
import time

#Algorithm 1: Enumeration
def alg1(array):

    head=tail=0
    low = array[0]
    if low < 0:
        low *= -1

    for i in range(0, len(array)):
        for j in range(i, len(array)):
            mySum = sum(array[i:j + 1])
            
            if mySum == 0:
            	low = mySum
               	head = i
               	tail = j
           
            elif mySum < 0:
                mySum *= -1

            if mySum < low:
                low = mySum
                head = i
                tail = j
                
    return (low, head, tail)


#Algorithm 2: Better Enumeration
def alg2(array):
	
	head=tail=0
	low = array[0]
	if low < 0:
		low *= -1
	
	for i in range(0, len(array)):
		mySum = 0
		for j in range(i, len(array)):
			mySum += array[j]
			
			if mySum == 0:
				low = mySum
				head = i
				tail = j
				
			elif mySum < 0:
				if (mySum * -1) < low:
					low=mySum * -1
					head = i
					tail = j
					
			if mySum < low:
				low = mySum
				head = i
				tail = j
	
	return (low, head, tail)
            

#Generate array of the specified amount of numbers      
def genArray(num):
	array = []
	random.seed()
	for i in range(0, num):
		x = random.randint(0, 999)
		y = random.randint(0, 999)
		if y > 650:
			x *= -1
		array.append(x)
	
	return array


#Run the test cases from a file: python subarray.py testfile.txt
def testCase():
	
	listArray = []	

	for line in fileinput.input():
		value = line.strip('\[\]\n ').split(',')
		listArray.append([int(x) for x in value])

	print "Algorithm 1 (Enumeration)"
	
	for arr in listArray:
		subarray = []
		subarraySum, head, tail = alg1(arr)
		
		for i in range(head, tail+1):
			subarray.append(arr[i])
		
		print arr,",",subarray,",", subarraySum
		
	print "\nAlgorithm 2 (Better Enumeration)"
	
	for arr in listArray:
		subarray = []

		subarraySum, head, tail = alg1(arr)
		
		for i in range(head, tail+1):
			subarray.append(arr[i])
		
		print arr,",",subarray,",",subarraySum

def timings():

	#Algorithm 1 timings
	print "Algorithm 1"
	for i in range(100, 1000, 100):
		runTimes=[]
		for j in range(0, 10):
			A = genArray(i)
			start = time.time()
			alg1(A)
			runtime = time.time() - start
			runTimes.append(runtime)
		print i, ",", sum(runTimes)/10
	
	
	#Algorithm 2 timings
	print "Algorithm 2"
	for i in range(100, 1000, 100):
		runTimes=[]
		for j in range(0, 10):
			A = genArray(i)
			start = time.time()
			alg2(A)
			runtime = time.time() - start
			runTimes.append(runtime)
		print i, ",", sum(runTimes)/10
	
	for i in range(1000, 10000, 1000):
		runTimes=[]
		for j in range(0, 10):
			A = genArray(i)
			start = time.time()
			alg2(A)
			runtime = time.time() - start
			runTimes.append(runtime)
		print i, ",", sum(runTimes)/10


def main():

	#This was used to run the test cases
	testCase()
	
	#This is for getting timings for experimental analysis
	#timings()
	



if __name__ == '__main__':

    main() 
