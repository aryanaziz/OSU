ReadMe.txt
Author: Aryan Aziz

There should be nothing special about this one, I ran testing on it about 20 times on a NON-html folder and the results looked good. 

To compile: gcc -o smallsh smallsh.c


