/**********
** Program: hello_world.cpp
** Author: Aryan Aziz
** Description: Prints "Hello!" to the console.
** Input: None
** Output: "Hello!" text to console
**********/

#include <iostream>
int main() {
	std::cout << "Hello World!" << std::endl;

	return 0;
}