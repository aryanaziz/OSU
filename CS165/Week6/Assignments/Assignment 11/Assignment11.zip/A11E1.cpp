/**********
** Program: A11E1.cpp
** Author: Aryan Aziz
** Description: Calls the functions in their namespaces
** Input: none
** Output: the functions
**********/

#include <iostream>
#include "A11E1-f.h"
#include "A11E1-g.h"

int main() {
	A::g();
	A::f();
	return 0;
}

