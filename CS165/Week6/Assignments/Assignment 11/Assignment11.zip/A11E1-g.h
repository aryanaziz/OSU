/**********
** Program: A11E1-g.h
** Author: Aryan Aziz
** Description: Defines the g namespace. 
** Input: none
** Output: none 
**********/

namespace A {
	void g();
}