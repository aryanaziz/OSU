/**********
** Program: A11E1-f.h
** Author: Aryan Aziz
** Description: Defines the f namespace 
** Input: none
** Output: none
**********/

namespace A {
	void f();
}